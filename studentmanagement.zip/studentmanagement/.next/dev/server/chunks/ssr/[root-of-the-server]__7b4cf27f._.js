module.exports = [
"[externals]/node:async_hooks [external] (node:async_hooks, cjs, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/[externals]_node:async_hooks_b485b2a4._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[externals]/node:async_hooks [external] (node:async_hooks, cjs)");
    });
});
}),
"[project]/node_modules/@smithy/credential-provider-imds/dist-es/index.js [app-rsc] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/node_modules_@smithy_credential-provider-imds_dist-es_eaf931ed._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/@smithy/credential-provider-imds/dist-es/index.js [app-rsc] (ecmascript)");
    });
});
}),
"[project]/node_modules/@aws-sdk/credential-provider-http/dist-es/index.js [app-rsc] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/[root-of-the-server]__846d18ec._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/@aws-sdk/credential-provider-http/dist-es/index.js [app-rsc] (ecmascript)");
    });
});
}),
"[project]/node_modules/@aws-sdk/credential-provider-sso/dist-es/index.js [app-rsc] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/node_modules_@aws-sdk_59fdd063._.js",
  "server/chunks/ssr/[root-of-the-server]__2a83735d._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/@aws-sdk/credential-provider-sso/dist-es/index.js [app-rsc] (ecmascript)");
    });
});
}),
"[project]/node_modules/@aws-sdk/credential-provider-ini/dist-es/index.js [app-rsc] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/node_modules_@aws-sdk_bbafef78._.js",
  "server/chunks/ssr/[root-of-the-server]__5cd7454a._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/@aws-sdk/credential-provider-ini/dist-es/index.js [app-rsc] (ecmascript)");
    });
});
}),
"[project]/node_modules/@aws-sdk/credential-provider-process/dist-es/index.js [app-rsc] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/[root-of-the-server]__66a0d3c2._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/@aws-sdk/credential-provider-process/dist-es/index.js [app-rsc] (ecmascript)");
    });
});
}),
"[project]/node_modules/@aws-sdk/credential-provider-web-identity/dist-es/index.js [app-rsc] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/node_modules_@aws-sdk_nested-clients_dist-es_submodules_sts_index_b9e0608e.js",
  "server/chunks/ssr/[root-of-the-server]__877211d6._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/@aws-sdk/credential-provider-web-identity/dist-es/index.js [app-rsc] (ecmascript)");
    });
});
}),
"[project]/node_modules/@smithy/core/dist-es/submodules/event-streams/index.js [app-rsc] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/node_modules_@smithy_core_dist-es_submodules_event-streams_4ce920d2._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/@smithy/core/dist-es/submodules/event-streams/index.js [app-rsc] (ecmascript)");
    });
});
}),
];