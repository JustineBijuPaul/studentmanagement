module.exports=[31667,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_students_route_actions_26715063.js.map