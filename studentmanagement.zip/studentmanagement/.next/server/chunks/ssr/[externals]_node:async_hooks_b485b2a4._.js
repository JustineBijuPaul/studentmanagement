module.exports=[78500,(a,b,c)=>{b.exports=a.x("node:async_hooks",()=>require("node:async_hooks"))}];

//# sourceMappingURL=%5Bexternals%5D_node%3Aasync_hooks_b485b2a4._.js.map